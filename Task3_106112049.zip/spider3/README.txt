MAIN(first) PAGE IS     index.php
To connect to server
host:-localhost
User:-root
Password:-(no password)

Name:-Kumar rishav
Roll no:-106112049
Dept:-cse
Email:-rishav006@gmail.com