<!DOCTYPE html>
<html language="en">
<head>
<title>task3</title>
<meta name="author" content="rishav">
<meta name="description" content="task3">
</head>
<body background="bc.jpg">
<h3 align="center"><font color="brown">!!!!!REGISTRATION SUCCESSFUL  ~  THANKS FOR REGISTERING!!!!!</font></h3>
<h5 align="center"><font color="green">TO LOGIN CLICK</font></h5>
<div align="center"><a href='index.php' onclick="history.go(+1);">[next]</a></div>
</body>
</html>