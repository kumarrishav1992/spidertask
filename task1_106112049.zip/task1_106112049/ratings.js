function rate1()
{
document.getElementById("star1").src="image.jpg";
}
function rate2()
{
document.getElementById("star1").src="images.jpg";
}
function rate3()
{
document.getElementById("star1").src="image.jpg";
document.getElementById("star2").src="image.jpg";
}
function rate4()
{
document.getElementById("star1").src="images.jpg";
document.getElementById("star2").src="images.jpg";
}
function rate5()
{
document.getElementById("star1").src="image.jpg";
document.getElementById("star2").src="image.jpg";
document.getElementById("star3").src="image.jpg";
}
function rate6()
{
document.getElementById("star1").src="images.jpg";
document.getElementById("star2").src="images.jpg";
document.getElementById("star3").src="images.jpg";
}
function rate7()
{
document.getElementById("star1").src="image.jpg";
document.getElementById("star2").src="image.jpg";
document.getElementById("star3").src="image.jpg";
document.getElementById("star4").src="image.jpg";
}
function rate8()
{
document.getElementById("star1").src="images.jpg";
document.getElementById("star2").src="images.jpg";
document.getElementById("star3").src="images.jpg";
document.getElementById("star4").src="images.jpg";

}
function rate9()
{
document.getElementById("star1").src="image.jpg";
document.getElementById("star2").src="image.jpg";
document.getElementById("star3").src="image.jpg";
document.getElementById("star4").src="image.jpg";
document.getElementById("star5").src="image.jpg";
}
function rate10()
{
document.getElementById("star1").src="images.jpg";
document.getElementById("star2").src="images.jpg";
document.getElementById("star3").src="images.jpg";
document.getElementById("star4").src="images.jpg";
document.getElementById("star5").src="images.jpg";
}