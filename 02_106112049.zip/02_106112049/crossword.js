function check()
{
if(
form.a.value=="M" &&
form.b.value=="A" &&
form.c.value=="T" &&
form.e.value=="S" &&
form.f.value=="A" &&
form.g.value=="L" &&
form.h.value=="E" &&
form.j.value=="I" &&
form.k.value=="C" &&
form.l.value=="A" &&
form.m.value=="P" &&
form.n.value=="E" &&
form.o.value=="R" &&
form.p.value=="A" &&
form.r.value=="I" &&
form.s.value=="R" &&
form.t.value=="E" &&
form.u.value=="U" &&
form.w.value=="D" &&
form.x.value=="E" &&
form.y.value=="N"
)
alert("CONGO! YOU WIN");
else
alert("SORRY! YOU LOST");
}
function result()
{
form.a.value="M" ;
form.b.value="A" ;
form.c.value="T" ;
form.e.value="S" ;
form.f.value="A" ;
form.g.value="L" ;
form.h.value="E" ;
form.j.value="I" ;
form.k.value="C" ;
form.l.value="A" ;
form.m.value="P" ;
form.n.value="E" ;
form.o.value="R" ;
form.p.value="A" ;
form.r.value="I" ;
form.s.value="R" ;
form.t.value="E" ;
form.u.value="U" ;
form.w.value="D" ;
form.x.value="E" ;
form.y.value="N" ;
}